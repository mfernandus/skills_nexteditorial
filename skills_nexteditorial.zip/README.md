# Skills da Next Editorial

Repositório privado com as skills que Mário Fernando usa no Claude para as rotinas da **ES Brasil**, da Comunhão, dos canais de YouTube e do comercial da Next Editorial.

São 26 skills, cada uma numa pasta dentro de `skills/` com o seu `SKILL.md` e, quando há, os arquivos de apoio (modelos, fontes, scripts, exemplos).

## Como usar

**No Claude Code**, adicione este repositório como marketplace e instale o plugin:

```
/plugin marketplace add mfernandus/skills_nexteditorial
/plugin install next-editorial-skills@next-editorial
```

Depois disso, todas as skills ficam disponíveis. Para atualizar quando o repositório mudar: `/plugin marketplace update next-editorial`.

**No app do Claude (claude.ai)**, cada pasta de `skills/` pode ser compactada em .zip e enviada em Configurações → Capacidades → Skills.

## Skills

### **ES Brasil** — conteúdo

| Skill | O que faz |
|---|---|
| `noticias-noturnas-esbrasil` | Turno noturno da ES Brasil (18h às 10h, 4 rodadas): apura em fonte oficial e publica uma matéria por editoria e vertical, parceiros primeiro, sem repetir a equipe. Sem Estilo nem Diversão e arte. |
| `estilo-diario-esbrasil` | Rodada diária de Estilo da ES Brasil: 1 matéria por subcategoria (7 por dia), com apuração, SEO e imagem, publicada direto. Única rotina de Estilo; use quando pedirem a rodada. |
| `diversao-e-arte-esbrasil` | Rotina diária de Diversão e Arte da ES Brasil: agenda cultural, estreias de cinema, shows, teatro, exposições e música capixaba, apuradas na base de fontes da editoria e publicadas direto. Use quando pedirem a rodada de Diversão e Arte. |
| `previsao-tempo-esbrasil` | Rotina diária da previsão do tempo da ES Brasil: às 19h prepara o Post A (dia seguinte + 3 dias), o Post B (2 dias) e o stories animado, e agenda tudo no NX Feed para 00h01. |
| `acervo-esbrasil` | Uma vez por dia, adapta uma matéria atemporal do acervo da ES Brasil, da Revista SAMP e do site esbrasil.com.br (NEIA, até 4 meses atrás), atualiza pessoas, cargos, dados e fatos datados e agenda para as 22h, nos Destaques até as 12h. |
| `artigos-acervo-esbrasil` | Rotina diária que republica às 8h, no site da ES Brasil, um texto autoral assinado do acervo (artigo, opinião ou gestão que não seja repercussão de factual), com in memoriam, data original, nota de contexto, regras de rejeição e story enviado para revisão da Joviana e do Mário. |
| `formula-1` | Fórmula 1 na ES Brasil em todo fim de semana de GP (sexta a domingo, 7h20, 13h20 e 19h20): ficha do GP refeita toda semana nas fontes oficiais, volume reduzido e fotos oficiais. Substitui a f1-gp-eua-2026. |
| `f1-gp-eua-2026` | Cobertura temporária do GP dos Estados Unidos de F1 (Austin, 22 a 25/10/2026) na ES Brasil — rodadas a cada 4h e boletins logo após cada treino, classificação e corrida. |
| `verificacao-es-em-numeros` | Verifica o site ES em Números (esemnumeros.esbrasil.com.br): erros, números novos nas fontes oficiais, coletores quebrados e fotos novas do NX Fotos. Use para a rodada semanal ou mensal. |

### Comunhão — conteúdo

| Skill | O que faz |
|---|---|
| `igreja-comunhao` | Editoria Igreja da Comunhão em 5 rodadas diárias (7h, 10h, 13h, 16h e 20h), 1 matéria publicada direto por rodada nos eixos igreja, gestão, estatísticas, tecnologia, audiovisual e direito. Carregar depois da padrao-publicacao-next. |
| `missoes-comunhao` | Produz e publica no portal Comunhão as matérias da editoria Missões (missões, igreja perseguida, evangelização) no padrão da casa, com fontes verificadas e box de serviço. |
| `acervo-comunhao` | Uma vez por dia, adapta uma matéria do acervo da Comunhão (NEIA, de 1997 até 4 meses atrás), atualiza pessoas, cargos, dados e fatos datados e agenda para as 22h, nos Destaques até as 12h. |
| `artigos-acervo-comunhao` | Rotina diária que republica às 8h, no site da Comunhão, um texto autoral assinado do acervo (artigo, opinião ou gestão que não seja repercussão de factual), com in memoriam, data original, nota de contexto, regras de rejeição e story enviado para revisão da Joviana e do Mário. |

### **ES Brasil** e Comunhão — transversais

| Skill | O que faz |
|---|---|
| `padrao-publicacao-next` | Regras comuns das rotinas que publicam nos sites ES Brasil e Comunhão via NX Feed (publicação, pautas proibidas, matéria agendada, duplicidade, fontes, direitos, SEO, imagem e avisos). Carregar antes de cada rotina. |
| `panorama-next` | Panorama (noticiário geral: Brasil, Mundo, clima e ciência, gente) da ES Brasil e da Comunhão em 5 rodadas por dia, a partir das agências do NX Feed, publicado direto. Roda junto com o esporte. |
| `esporte-noturno-next` | Esporte da ES Brasil e da Comunhão em 5 rodadas por dia (7h, 12h, 16h, 21h50, 23h50): resultados, notícias e resumo do Brasileirão, publicados direto. O noticiário geral fica na panorama-next. |
| `monitor-audiencia-next` | Gera a análise de audiência dos sites da Next — ES Brasil e Comunhão — lendo o audiencia-latest.json do coletor. Entrega painel HTML no padrão Next e resumo curto de WhatsApp, sempre lendo o dia contra a base de sete dias e com selos REAL/REFERENCIA/SIMULADO/PENDENTE. |

### YouTube

| Skill | O que faz |
|---|---|
| `youtube-esbrasil-titulos` | Publica de ponta a ponta um vídeo do canal Revista ES Brasil no YouTube: títulos A/B, descrição, capítulos, tags, cards, tela final, playlists, capa nos templates ES Brasil Entrevista, Destinos ES e Café com Moqueca, e 3 a 5 Shorts com moldura e capa oficiais. Pergunta o tipo de capa no início e pede ok antes de salvar no Studio. Download do original já liberado. |
| `youtube-comunhao-titulos` | Publica de ponta a ponta um vídeo da Revista Comunhão no YouTube: títulos A/B, descrição, tags, cards, tela final, capa publicada e 3 a 5 Shorts com capa, prontos no canal. Download do original já liberado. |
| `youtube-lote-noturno-next` | Roda em lote, por comando, a atualização dos vídeos dos canais da Next Editorial no YouTube em modo noturno, com teste A/B nativo de capas, Shorts exportados para as redes e a Central sempre atualizada. |
| `youtube-playlists-next` | Organiza e mantém as playlists e a página inicial dos canais Revista ES Brasil e Revista Comunhão no YouTube, no modelo em camadas (programa, editoria, tema, especial, cortes): inventário, diagnóstico, plano para aprovação, aplicação no Studio depois do ok e manutenção semanal. |

### Comercial e documentos

| Skill | O que faz |
|---|---|
| `analise-semanal-vendas-next` | Gera a Análise Semanal de Vendas da Next Editorial — performance individual dos executivos (propostas geradas, aprovadas, pendentes) espelhada com a meta, análise do time no gráfico, e leitura imediata de fechamento da semana. Analisa por produto, por produto editorial e por projeto, com dados do NextorCRM. Acione sempre que o usuário pedir "análise de vendas", "relatório de performance", "como está o time", "fechamento da semana", "análise por executivo", ou quando a tarefa agendada das 18:30 disparar. Também é a skill canônica do painel comercial diário/semanal da casa. |
| `cartas-comerciais-next-editorial` | Gera cartas comerciais de propostas de veiculação no padrão Next Editorial — para ES Brasil, Comunhão, Destinos ES e Prócidade. Use esta skill sempre que o usuário pedir uma carta, proposta comercial, oferta publicitária, oferta de mídia, proposta de patrocínio, carta de prospecção, ou qualquer comunicação dirigida a um cliente/anunciante com proposta de presença editorial — mesmo quando ele não usar literalmente a palavra "carta". Também acione quando ele apenas der os insumos (destinatário + edição + investimento) sem explicitar o pedido. Esta é a skill canônica da casa para o padrão de cartas comerciais Next Editorial. |
| `documentos-next-editorial` | Gera documentos e relatórios no padrão visual da Next Editorial — Borderô (NX Fina), Espelho de paginação, Relatório de Metas (NextorCRM) e Next Performance Report — e documentos no Estilo Pessoal de Mário Fernando (verde-escuro, verde cítrico, navy e cinza). Use SEMPRE que o usuário pedir para criar, montar ou formatar relatório, borderô, espelho, plano de metas, relatório de performance ou comercial, ou qualquer documento interno da Next Editorial, ES Brasil, Comunhão, Destinos ES ou Prócidade, mesmo sem dizer "no padrão"; e quando pedir algo "no meu estilo", "estilo pessoal" ou "estilo Mário Fernando". Acione também quando ele der só os dados sem explicitar o formato. Aplica Inter, paletas por marca, logos oficiais, grade A4 e selos de proveniência. |

### Utilitários

| Skill | O que faz |
|---|---|
| `karpathy-guidelines` | Behavioral guidelines to reduce common LLM coding mistakes. Use when writing, reviewing, or refactoring code to avoid overcomplication, make surgical changes, surface assumptions, and define verifiable success criteria. |
| `nx-mac-clean` | Limpeza e otimização diária do Mac de Mário + triagem da caixa de e-mail. Use quando ele pedir para 'limpar a máquina', 'otimizar o Mac', 'liberar espaço', 'deixar o Mac mais rápido', 'fazer a manutenção diária', 'limpar as porcarias do computador', 'limpar os e-mails' ou 'organizar a caixa de entrada' — mesmo sem citar CleanMyMac. Requer shell local no Mac (Desktop Commander ou máquina conectada). |

## Observações

- `f1-gp-eua-2026` foi a cobertura temporária do GP dos EUA e já foi substituída pela `formula-1`; fica aqui como histórico.
- Este repositório deve continuar **privado**: algumas skills citam contas Google, rotinas internas e fluxos de publicação da casa.
- Versão de referência: skills como estavam na conta em 02/11/2026.
