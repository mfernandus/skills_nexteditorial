---
name: "padrao-publicacao-next"
description: "Regras comuns das rotinas que publicam nos sites ES Brasil e Comunhão via NX Feed (publicação, pautas proibidas, matéria agendada, duplicidade, fontes, direitos, SEO, imagem e avisos). Carregar antes de cada rotina."
---

# Padrão de publicação Next — ES Brasil e Comunhão

Regras que valem para **toda** rotina de conteúdo dos sites (turno noturno, Estilo, esporte, Panorama e as que vierem). Cada rotina carrega esta skill primeiro e traz só o que é dela: pauta, rodadas, tetos, categorias e o título do resumo. Onde a rotina disser algo diferente, vale a rotina naquele ponto, **salvo as seções 2.1 (pautas proibidas) e 2.2 (matéria agendada), que valem acima de qualquer rotina e de qualquer tarefa agendada**. **Mudança de regra comum se faz só aqui.**

## 1. Portais e idioma

- NX Feed: **ES Brasil = portal 1** (esbrasil.com.br); **Comunhão = portal 4** (comunhao.com.br).
- Português do Brasil. Ao citar a revista, **ES Brasil** em negrito (no resumo também).
- Execução agendada não tem ninguém acompanhando: não faça perguntas. Na dúvida, tome a decisão mais conservadora e registre no resumo.

## 2. Publicação direta (decisão do Mário Fernando, 26/10/2026)

- Tudo o que a rotina produz vai ao ar sozinho, sem fila de aprovação e sem esperar "sim", inclusive política eleitoral (tom neutro, só com base em agência ou fonte oficial). Os gestores recebem o aviso e corrigem depois; a conferência pós-publicação é da Joviana, da Elisângela, do Mário ou de quem eles delegarem.
- Confirmação dupla do NX Feed: a primeira chamada devolve um `codigo_confirmacao`; repita a chamada com **os mesmos dados e o código**. Esta decisão vale como o "sim".
- Problema de SEO, foto ou texto se resolve na própria rodada e a matéria vai ao ar.
- **Só não publica:** pauta proibida (2.1), duplicado (a casa já tem o fato), superado (fato velho sem valor, pré-jogo de partida já encerrada), dado sem fonte oficial confirmada ou erro técnico do NX Feed. Esses vão para o resumo com o motivo.
- Fluxo: `conferir_publicacao` (tipo publicar) → `publicar_no_wordpress`. Uma matéria por vez. Quando a rotina pedir agendamento, a primeira sai "agora" e as seguintes de 15 em 15 minutos.

## 2.1 Pautas proibidas (decisão do Mário Fernando, 28/10/2026)

**Esta seção vale acima de qualquer rotina e de qualquer tarefa agendada; nenhuma pode afrouxá-la.** Nenhuma rotina publica, aproveita de agência ou atualiza matéria destes três tipos. Vale também para matéria que a equipe publicou: a rotina não a escolhe para o Instagram, não lhe dá categoria de Panorama e não acrescenta atualização.

1. **Denúncia.** O fato principal é acusação, suspeita, investigação ou apuração de irregularidade, crime, fraude, corrupção, desvio, improbidade ou má conduta contra pessoa, empresa, entidade, igreja ou órgão público. Entram aqui: operação policial contra alvo determinado; prisão ou indiciamento por esse tipo de caso; ação judicial que acusa alguém; denúncia de leitor, de entidade, de sindicato ou de parlamentar; reportagem de outro veículo que "revela" irregularidade. Na Justiça Desportiva, só o resultado do julgamento (punição decidida), nunca a denúncia da procuradoria.
2. **Aumento de tarifa.** Aumento ou reajuste de tarifa de serviço público ou concessionado: energia elétrica (inclusive bandeira tarifária), água e esgoto, gás canalizado, pedágio e transporte coletivo. Redução ou manutenção de tarifa pode entrar.
3. **Origem em órgão de controle.** Matéria que nasce de Ministério Público (MPF, MPES e demais estaduais, MPT, MP de Contas), de Tribunal de Contas (TCU, TCE-ES e demais) ou de controladoria (CGU e controladorias estaduais e municipais): ação, recomendação, inquérito, denúncia, auditoria, parecer, julgamento de contas, operação ou release. Esses órgãos também não servem de fonte para outras matérias.

Na dúvida se o assunto se encaixa, não publique. Registre no resumo, em "Também na rodada", com o título e a marca "fora por regra de pauta".

## 2.2 Matéria agendada só existe quando vai ao ar (decisão do Mário Fernando, 30/10/2026)

**Esta seção vale acima de qualquer rotina e de qualquer tarefa agendada, como a 2.1.** Matéria agendada no WordPress, pela equipe ou por uma rotina, ainda não está no ar: o leitor não a vê e o link dela não abre. Até a hora em que ela vai ao ar (`vai_ao_ar`):

1. **Nenhuma rede social.** Não crie arte, story, post, carrossel ou reels dela. Não aprove, não agende e não publique nada dela no Instagram, no Facebook ou em outra rede, nem a mande ao WhatsApp. Vale também para a matéria que a própria rotina acabou de agendar.
2. **Conteúdo de rede que já existe** (o NX Feed cria story ou post sozinho, com o Claude pela API, na hora em que a matéria é agendada): não mande "publicar agora" e não ponha horário antes do `vai_ao_ar`. O horário certo é o do `vai_ao_ar` ou depois. Se a matéria foi reagendada, o conteúdo de rede vai junto para o novo horário. Nunca escreva em nota, legenda ou resumo que o conteúdo deve sair "antes" da matéria.
3. **Nenhuma mexida em matéria agendada da equipe.** Não a publique "agora", não mude o horário, não a reenvie (`publicar_no_wordpress`, `atualizar_no_wordpress`, `enviar_rascunho_ao_wordpress`), não a edite (`editar_materia`, `definir_imagem_destacada`), não lhe dê Destaques nem Panorama e não a use como link interno.
4. **Na trava de duplicidade ela conta** (seção 4): a casa já tem o fato, então não escreva sobre o mesmo assunto.

**Como reconhecer.** Em alguns lugares o NX Feed trata "enviada ao WordPress" como "publicada":
- `materias_para_instagram` lista como publicada a matéria só agendada (`publicada_em` = hora do envio). Antes de usar qualquer item dela, rode `listar_agendamentos` do portal (de agora até 7 dias, todas as páginas) e descarte todo `materia_id` que aparecer ali. Depois confirme que o item está em `listar_publicacoes` com situação "publicado".
- Link com `?p=` (ex.: esbrasil.com.br/?p=417326) no lugar do endereço com o slug: trate como agendada.
- `listar_materias` com `estado` = publicado já deixa as agendadas de fora (elas têm `estado` = agendado). `listar_publicacoes` mistura as duas: filtre `situacao` = publicado.

Na dúvida, fica fora. Registre no resumo, em "Também na rodada", como "aguardando ir ao ar (DD/MM HHh)".

## 3. NX Feed: cuidados de uso

- Carregue as ferramentas com ToolSearch e faça **uma chamada de cada vez** (códigos de confirmação pedidos em paralelo se invalidam).
- Erro 429 ou aviso de espera: espere o tempo indicado e repita a mesma chamada. Não pule o item por isso.
- Os filtros de `categoria` e `estado` de `listar_materias` não separam portais (os ids colidem): nas listagens de publicadas, passe sempre `portal`.
- Rascunho que ainda não foi ao WordPress não tem portal: busque rascunhos **sem** filtro de portal e confira o destino com `ver_materia`.
- `editar_materia` com "categorias" **substitui as categorias de todos os portais**: leia antes com `ver_materia` (pegue a `versao`) e mande as categorias de todos os portais já com a mudança. Ao reenviar, passe `portais` só com os portais em que a matéria já tem post (senão o NX Feed cria rascunho no outro).
- Para atualizar um post no ar sem mudar o status: `enviar_rascunho_ao_wordpress` (ou `atualizar_no_wordpress` num portal só).
- Mexa só nas matérias da própria rotina (criadas ou editadas via Claude; `historico_da_materia` mostra), nunca nos rascunhos da equipe, a não ser que a rotina diga o contrário. Matéria agendada da equipe nunca: seção 2.2.
- Id de categoria recusado: rode `listar_categorias_wordpress` no portal, use o id atual da **mesma** categoria e avise no resumo. Nunca grave em categoria aproximada.
- **Destaques** (11966 na ES Brasil, 44517 na Comunhão) é da redação e de só duas rotinas (decisão do Mário Fernando, 30/10 e 02/11/2026): (1) a **rotina de Destaques**, de hora em hora, que põe e tira as matérias automáticas, inclusive o esporte, com mais espaço nos fins de semana, feriados e noites de jogo; (2) as **rotinas de acervo** (`acervo-comunhao` e `acervo-esbrasil`), que agendam a matéria das 22h já com Destaques e a deixam lá até o meio-dia seguinte. Nenhuma outra rotina, nem a de esporte, marca ou tira Destaques.

## 4. Trava de duplicidade

Faça antes de escrever e de novo **imediatamente antes de publicar**:

1. O que já foi ao ar no portal (`listar_publicacoes` ou `listar_materias` publicadas, com `portal`), na janela que a rotina indicar.
2. Rascunhos (`estado` = rascunho e depois rascunho_no_wp), sem filtro de portal.
3. `listar_materias` com `busca` pelo fato, pessoa, empresa, órgão ou time (todos os estados) e WebSearch `site:<domínio do portal> <tema>`.

Se a casa já tem o mesmo fato, publicado ou em rascunho da equipe, não escreva: troque por **outro assunto do mesmo tema** (outro dado, outra empresa, outro município, desdobramento realmente novo) ou registre "coberto pela equipe". Nunca publique o item de feed **e** uma matéria manual sobre o mesmo fato.

## 5. Fontes e apuração

- A fonte oficial ou primária (órgão público, entidade, documento, release no site da própria empresa, dado público) é a fonte de verdade. Órgão de controle (Ministério Público, Tribunal de Contas, controladoria) não serve de fonte (2.1). Abra com WebFetch antes de escrever; nunca redija a partir de snippet. Fonte que não abre: procure outra ou troque a pauta. Não use curl ou Python para burlar página bloqueada.
- Imprensa serve só de pista e de conferência. **Não dê crédito a outro veículo:** não cite, não linke, não escreva "segundo o jornal X". A atribuição vai para a fonte oficial.
- Agências contratadas que chegam no NX Feed (Agência Brasil, Estadão Conteúdo e as demais cadastradas) podem ser aproveitadas, com o crédito no rodapé.
- O que só existe no outro veículo (entrevista exclusiva, levantamento próprio, bastidor) não entra. Se o fato depende disso, troque a pauta.
- Dado que não bate: vale o oficial. Dado que não deu para confirmar: fica de fora e vai para o resumo.
- Nunca invente fala, número ou data. Citação só quando a fonte a publicou, curta e atribuída.
- Na apuração, guarde um ou dois dados conferidos que **não** vão entrar no texto: se a matéria acabar com imagem por IA, um deles vira a legenda-fato (9.2).

## 6. Direitos autorais

- Texto sempre próprio ou de agência contratada com crédito. Reescreva com estrutura e palavras próprias; nunca copie nem traduza parágrafos de outro veículo; não siga a ordem, o título nem as frases da matéria que serviu de pista.
- Foto só com direito de uso: acervo da casa (NX Fotos, ES Brasil, Comunhão), Agência Brasil, Fotos Públicas ou divulgação oficial com crédito visível (governo, prefeitura, empresa, entidade, clube, federação, liga).
- **Proibido:** Reuters, AFP, AP, Getty, Zimel/Estadão, USA Today/Imagn, Shutterstock/iStock/Freepik achados na web, Pinterest, Instagram de terceiros, "Reprodução" sem dono, foto de jornal ou de outro veículo, Google Imagens sem dono e licença claros. Item da Agência Brasil com `imagem_reuters` = true: troque a foto.
- Na dúvida sobre o direito de uso, não use a foto: vá para a imagem por IA (9.1).

## 7. Padrão do texto (comum a todas)

- Autor "Redação" (ou o crédito da agência, quando o item é aproveitado). Chapéu em maiúsculas.
- **Título até 60 caracteres, contando espaços**, informativo, com a palavra-chave de preferência no início. Se passar, corte o acessório e leve o complemento para a linha fina (uma frase).
- Abertura de 25 a 70 palavras respondendo ao título (o quê, quem, quando, onde).
- Um link externo para a fonte oficial: `<a href="..." target="_blank" rel="noopener">`. Links internos para matérias do próprio portal, quando houver.
- Rodapé: `<p><em>Com informações de [fonte]</em></p>`.
- Datas como "neste domingo (25)", nunca "ontem" ou "hoje". Confira no calendário o dia da semana de toda data. Valores com a unidade da fonte.
- Política: tom neutro, sem adjetivos, mesmo espaço aos lados; em eleição, só números oficiais (TRE-ES/TSE) e nada de pesquisa avulsa.
- Saúde e pet: sem dose nem prescrição; oriente a procurar o profissional.
- **Bíblia (vale para toda rotina da Comunhão e para qualquer rotina que cite a Bíblia):** Toda citação bíblica escrita pela redação sai **sempre na NTLH** (Nova Tradução na Linguagem de Hoje; decisão de Mário Fernando, 2/11/2026), conferida palavra por palavra no NEIA com `get-bible-passage` e `bible_code` "NTLH". Nunca ACF, ARC, ARA, NVI, NVT ou outra versão no texto da redação, mesmo que o original ou a fonte tragam: troque pelo texto da NTLH do mesmo versículo e registre no resumo. **Quando quem cita é uma pessoa** (fala, entrevista, depoimento, texto de articulista ou de autor convidado) e ela usou outra versão, fica a versão dela; só a forma da referência é padronizada. Confira também se a referência bate com o episódio citado. Formato da casa: citação curta, entre aspas, com a referência entre parênteses depois, ex.: "Porém a maior delas é o amor" (1 Coríntios 13.13), sem ler nem repetir a versão no texto. Na NTLH, a numeração de alguns versículos difere da de outras versões: use a da NTLH no texto da redação.
- Tamanho do texto, nível dos intertítulos e shortcodes: cada rotina define.
- Antes de gerar texto, `prompt_do_nxfeed` traz a linha editorial do NX Feed: siga-a.

## 8. SEO

- Palavra-chave de 2 a 4 palavras, escrita igual no 1º parágrafo, em um intertítulo e 2 ou mais vezes no texto.
- Título SEO ≤ 60 começando por ela; meta description ≤ 155 caracteres, só com números e datas que estão no texto e na mesma grafia; slug minúsculo com hífens, ≤ 51; 5 a 10 tags (a rotina pode pedir mais).
- **Nota SEO ≥ 85.** Se vier abaixo, corrija com `editar_materia` (`trocar_trecho`) até duas tentativas; depois publique com a nota que tiver e avise no resumo.

## 9. Imagem destacada

- A rotina escolhe e grava a foto sozinha; **o Mário não escolhe foto**. Critérios, nesta ordem: (1) informação — mostra o fato, o lugar, o produto ou as pessoas da matéria; (2) atualidade — a mais recente que sirva (evite obra inacabada ou cenário que já mudou); (3) beleza e qualidade — nítida, bem composta, boa luz, horizontal, de preferência ≥ 1200 px.
- **Onde cada campo aparece no site:** a **descrição** é a legenda visível embaixo da imagem, seguida automaticamente de " – Foto: <fonte>/<autor>"; a **legenda** é o texto alternativo (alt), que o leitor não vê; o **título** é o nome interno da mídia; **fonte** e **autor** formam o crédito.
- Ordem de busca (a rotina pode mudar): `buscar_imagens` recomendadas (materia_id) → NX Fotos (termo) → editoriais (termo) → divulgação oficial com crédito. Olhe a foto antes de gravar. Em foto real, a descrição diz o que ela mostra.
- Sem foto do próprio fato (obra que não começou, estudo, indicador): foto real de acervo do mesmo tipo de cena, com "imagem ilustrativa" na descrição; "foto de arquivo" quando for. Pessoa citada no título: foto dela.
- Grave com `definir_imagem_destacada` preenchendo título, fonte, autor, descrição e legenda (alt): esses campos vão para o WordPress.
- Recusa por "dimensões muito grandes": use a versão reduzida que o WordPress do próprio site gera (o mesmo arquivo com sufixo como -1536x1024).
- Nunca rosto de menor identificável em contexto sensível.

### 9.1 Imagem por IA (último recurso; autorizada em 26/10/2026 para todas as rotinas)

Só quando nenhuma foto real com direito de uso servir:

- Krea: `mcp__Krea_AI__generate_image` (carregue com ToolSearch), modelo `krea/krea-2/large`, `aspect_ratio` 16:9, `resolution` 1K, `sync` = true.
- Prompt em inglês, com uma cena **genérica e ilustrativa** do tema, terminando com: "photorealistic editorial photo, natural light, no text, no logos, no recognizable faces".
- **Proibido gerar:** pessoa real ou identificável; rosto de personagem da matéria; criança em contexto sensível; marca, logotipo, fachada, produto ou coleção de empresa real; escudo, uniforme ou patrocinador de clube real; símbolo ou templo de denominação específica; lugar reconhecível como se fosse foto real; recriar o próprio fato (gol, ataque, acidente, discurso, evento noticiado) como se fosse foto; procedimento, remédio ou dose; animal em sofrimento.
- Olhe a imagem antes de gravar. Com defeito visível (mãos, rostos, objetos deformados, texto), gere de novo **uma** vez.
- Grave com `definir_imagem_destacada`: fonte "Imagem gerada por IA"; autor "Krea AI / ES Brasil" (só Comunhão: "Krea AI / Comunhão"); título curto com o assunto da matéria; **descrição = a legenda-fato (9.2)**; legenda (alt) com até 125 caracteres dizendo o que a ilustração mostra, terminando com "(imagem ilustrativa gerada por IA)".
- Se a Krea falhar (saldo ou erro), publique sem imagem e avise.
- Toda imagem de IA entra no resumo, na seção "Imagens de IA para validar", com a legenda-fato. É validação, não aprovação: não espere resposta.

### 9.2 Legenda-fato da imagem por IA (decisão do Mário Fernando, 26/10/2026)

A descrição é o texto que aparece embaixo da imagem no site, seguido do crédito "Foto: Imagem gerada por IA/Krea AI / …", que já avisa que é ilustração. Por isso ela **não descreve a imagem**: entrega ao leitor um dado a mais sobre o assunto da matéria.

1. **Assunto, não cena.** Fala do tema da matéria, nunca do que a ilustração mostra. Nada de "na imagem", "na foto", "ilustração de".
2. **Fato novo.** Não está no título, na linha fina nem no texto: dado, número, data, regra, histórico ou serviço. Antes de gravar, confira que os números e os termos-chave da frase não aparecem no texto.
3. **Conferido e atribuído.** Vem de fonte oficial aberta com WebFetch e leva a atribuição na frase ("segundo o IBGE", "de acordo com a Anvisa"). Nunca de memória, nunca inventado.
4. **Coerente.** Não contradiz o texto nem muda o foco da matéria.
5. **Uma frase de 100 a 220 caracteres**, informativa: sem pergunta, chamada, exclamação ou adjetivo de propaganda.
6. **Saúde e pet:** sem dose nem prescrição. **Política:** dado oficial e neutro.
7. **Sem fato novo** conferido depois de duas buscas extras: use o dado de serviço mais útil da própria matéria (data, local, horário, prazo, canal de atendimento) e marque "legenda sem fato novo" no resumo.

Exemplos (matéria sobre apreensão de lote falsificado de toxina botulínica):
- Errado (descreve a imagem): "Sala de clínica de estética vazia, com cadeira reclinável branca e janela com cortinas claras."
- Errado (repete a matéria): "Anvisa manda apreender novo lote falsificado de toxina botulínica."
- Certo (forma): "<fato que o texto não traz, com número ou data>, segundo <fonte oficial>." Por exemplo: "O Espírito Santo tem N estabelecimentos de estética licenciados pela Vigilância Sanitária, segundo a Sesa." O número e a fonte vêm sempre da apuração do dia.

## 10. Avisos ao fim da rodada

**Não envie e-mail** (decisão do Mário Fernando, 27/10/2026). O aviso da rodada é o resumo na conversa e a notificação do app.

1. **Resumo na conversa** (SendUserMessage), curto, para celular, com o título que a rotina define. Se a execução rodar mais de uma rotina, um resumo só, com uma parte por rotina. Seções, nesta ordem:
   - **Publicadas:** título com o link no ar, portal e categoria;
   - **Imagens de IA para validar:** link da matéria, link da imagem e a legenda-fato (ou "legenda sem fato novo"), com a frase "Se precisar, troque no NX Feed.";
   - **Também na rodada:** o que não foi publicado e o motivo (fora por regra de pauta, duplicado, superado, erro técnico), ajustes em matérias da redação, casos marcados "envolve parceiro";
   - **Pendências:** erro técnico, SEO abaixo de 85, categoria recusada, dado não confirmado, conector fora.
   - Seção sem itens: "nenhuma". A rotina pode acrescentar a parte própria dela (tabelas, metas, contagens).
2. **Notificação do app Claude:** só quando houver matéria nova ou problema (a rotina pode pedir sempre). Rodada sem novidade termina com "Sem fato novo nesta rodada", sem notificação.